import tensorflow as tf
print(tf.__version__)